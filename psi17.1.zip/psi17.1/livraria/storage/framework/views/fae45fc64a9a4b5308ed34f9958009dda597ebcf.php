<form action="<?php echo e(route('livros.store')); ?>" method="post">
	<?php echo csrf_field(); ?>
	Titulo:<input type="text" name="titulo" value="<?php echo e(old('titulo')); ?>"><br>
	<?php if($errors->has('titulo')): ?>
	Deverá indicar um Titulo correto <br>
	<?php endif; ?>
	Idioma:<input type="text" name="idioma" value="<?php echo e(old('idioma')); ?>"><br>
	<?php if($errors->has('idioma')): ?>
	Deverá indicar um Idioma correto <br>
	<?php endif; ?>
	Total páginas:<input type="text" name="total_paginas" value="<?php echo e(old('total_paginas')); ?>"><br>
	<?php if($errors->has('total_paginas')): ?>
	Deverá indicar um Total páginas correto <br>
	<?php endif; ?>
	Data Edição:<input type="text" name="data_edicao" value="<?php echo e(old('data_edicao')); ?>"> <br>
	<?php if($errors->has('data_edicao')): ?>
	Deverá indicar um Data Edição correto <br>
	<?php endif; ?>
	ISBN:<input type="text" name="isbn" value="<?php echo e(old('isbn')); ?>"><br>
	<?php if($errors->has('isbn')): ?>
	Deverá indicar um ISBN correto <br>
	<?php endif; ?>
	Observações:<textarea name="observacoes" value="<?php echo e(old('observacoes')); ?>"></textarea><br>
	<?php if($errors->has('observacoes')): ?>
	Deverá indicar um Observações correto <br>
	<?php endif; ?>
	Imagem capa:<input type="text" name="imagem_capa" value="<?php echo e(old('imagem_capa')); ?>"><br>
	<?php if($errors->has('imagem_capa')): ?>
	Deverá indicar um Imagem capa correto <br>
	<?php endif; ?>
	Género:<input type="text" name="id_genero" value="<?php echo e(old('id_genero')); ?>"><br>
	<?php if($errors->has('id_genero')): ?>
	Deverá indicar um ISBN correto <br>
	<?php endif; ?>	
	Autor:<input type="text" name="id_autor" value="<?php echo e(old('id_autor')); ?>"> <br>
	<?php if($errors->has('id_autor')): ?>
	Deverá indicar um Género correto <br>
	<?php endif; ?>
	Sinopse:<textarea name="sinopse" ><?php echo e(old('sinopse')); ?></textarea><br>
	<?php if($errors->has('sinopse')): ?>
	Deverá indicar um Sinopse correto <br>
	<?php endif; ?>              
	<input type="submit" value="enviar">
	
	
	
</form><?php /**PATH D:\psi17\livraria\resources\views/livros/create.blade.php ENDPATH**/ ?>