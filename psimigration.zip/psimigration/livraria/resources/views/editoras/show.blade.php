ID:{{$editora->id_editora}}<br>
Nome:{{$editora->nome}}<br>
Morada:{{$editora->morada}}



<a href="{{route('editoras.edit', ['id'=>$editora->id_editora])}}">Editar</a>

<a href="{{route('editoras.delete', ['id'=>$editora->id_editora])}}">Eliminar</a>