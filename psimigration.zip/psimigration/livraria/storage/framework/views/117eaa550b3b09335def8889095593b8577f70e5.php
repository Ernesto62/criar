<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="<?php echo e(route('generos.update',['id'=>$genero->id_genero])); ?>" method="post">
<?php echo csrf_field(); ?>
<?php echo method_field('patch'); ?>
Designação: <input type="text" name="designacao" value=""><br><br>
<?php if($errors->has('designacao')): ?>
Deverá indicar uma designaçãov válida<br>
<?php endif; ?>

Observacoes: <textarea type="text" name="observacoes" ></textarea><br><br>
<input type="submit" value="Enviar!">
</form>
</body>
</html><?php /**PATH D:\psi17.1\livraria\resources\views/generos/edit.blade.php ENDPATH**/ ?>