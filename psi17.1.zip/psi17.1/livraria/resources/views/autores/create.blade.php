<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="{{route('autores.store')}}" method="post">
@csrf
Nome: <input type="text" name="nome"><br>
@if($errors->has('nome'))
Deverá indicar um nome correto<br>
@endif
Nacionalidade: <input type="text" name="nacionalidade" value=""><br>
@if($errors->has('nacionalidade'))
Deverá indicar uma nacionalidade correta<br>
@endif
Data Nascimento <input type="date" name="data_nascimento">
@if($errors->has('data_nascimento'))
Deverá indicar uma data de nascimento correta <br>
@endif
<input type="submit" value="Enviar!">
</form>








</body>
</html>