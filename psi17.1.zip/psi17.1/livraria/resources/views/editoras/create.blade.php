<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="{{route('editoras.store')}}" method="post">
@csrf
Nome: <input type="text" name="nome" value=""><br>
@if($errors->has('nome'))
Deverá indicar um nome correto<br>
@endif
Morada: <input type="text" name="morada"><br>
@if($errors->has('morada'))
<i>Deverá indicar uma morada correta <br>
@endif
<input type="submit" value="Enviar!">
</form>





</body>
</html>