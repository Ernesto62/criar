ID:<?php echo e($livro->id_livro); ?><br>
Título:<?php echo e($livro->titulo); ?><br>
Idioma:<?php echo e($livro->idioma); ?><br>

<?php if(isset($livro->genero->designacao)): ?>
Genero:<?php echo e($livro->genero->designacao); ?><br>
<?php endif; ?>

<?php if(isset($livro->editora->nome)): ?>
Editora:<?php echo e($livro->editora->nome); ?><br>
<?php endif; ?>

<?php if(count($livro->autores)>0): ?>


<?php $__currentLoopData = $livro->editoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
Autor:<?php echo e($editora->nome); ?><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__currentLoopData = $livro->autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
Autor:<?php echo e($autor->nome); ?><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>
<div class="alert alert-danger" role="alert">Sem autor definido </div>
<?php endif; ?>





<a href="<?php echo e(route('livros.edit', ['id'=>$livro->id_livro])); ?>">Editar</a>


   
<a href="<?php echo e(route('livros.delete', ['id'=>$livro->id_livro])); ?>">Eliminar</a>

<?php /**PATH D:\psi17.1\livraria\resources\views/livros/show.blade.php ENDPATH**/ ?>