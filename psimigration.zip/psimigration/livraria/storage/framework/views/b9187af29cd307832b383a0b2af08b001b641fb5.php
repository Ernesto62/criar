<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="<?php echo e(route('livros.update',['id'=>$livro->id_livro])); ?>" method="post">
<?php echo csrf_field(); ?>
<?php echo method_field('patch'); ?>
Titulo: <input type="text" name="titulo" value=""><br><br>
<?php if($errors->has('titulo')): ?>
Deverá indicar um titulo válido<br>
<?php endif; ?>

Idioma: <input type="text" name="idioma" value=""><br><br>
Total Páginas: <input type="text" name="total_paginas" value=""><br><br>

Data Edição: <input type="date" name="data_edicao" value=""><br><br>
ISBN: <input type="text" name="isbn" value=""><br><br>
<?php if($errors->has('isbn')): ?>
Deverá indicar um ISBN correto (13 caracteres)
<?php endif; ?>

Observacoes: <textarea type="text" name="observacoes" ></textarea><br><br>
Imagem de capa: <input type="text" name="imagem_capa"><br><br>


Editora(s):
<select name="id_editora">
	<?php $__currentLoopData = $editoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<option value="<?php echo e($editora->id_editora); ?>"

		<?php if($editora->id_editora==$livro->id_editora): ?>selected <?php endif; ?>

		><?php echo e($editora->nome); ?></option>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><br><br>


Género(s):
<select name="id_genero">
	<?php $__currentLoopData = $generos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<option value="<?php echo e($genero->id_genero); ?>"

		<?php if($genero->id_genero==$livro->id_genero): ?>selected <?php endif; ?>

		><?php echo e($genero->designacao); ?></option>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><br><br>


Autor(es):
<select name="id_autor[]" multiple="multiple">
	
	<?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<option value="<?php echo e($autor->id_autor); ?>"
		<?php if(in_array($autor->id_autor, $autoresLivro)): ?>selected 
		<?php endif; ?>
		><?php echo e($autor->nome); ?>

	</option>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<br><br>
Sinopse: <textarea type="text" name="sinopse"></textarea> <br><br>


<br><br>


<br>
<br>
<input type="submit" value="Enviar!">
</form>
</body>
</html>

<?php /**PATH D:\psi17.1\livraria\resources\views/livros/edit.blade.php ENDPATH**/ ?>