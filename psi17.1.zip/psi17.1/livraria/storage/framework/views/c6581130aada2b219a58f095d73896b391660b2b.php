<form action="<?php echo e(route('livros.store')); ?>" method="post">
	<?php echo csrf_field(); ?>
	Titulo:<input type="text" name="titulo"><br>
	Idioma:<input type="text" name="idioma"><br>
	Total páginas:<input type="text" name="total_paginas"><br>
	Data Edição:<input type="text" name="data_edicao"><br>
	ISBN:<input type="text" name="isbn" value="<?php echo e(old('isbn')); ?>"><br>
	<?php if($errors->has('isbn')): ?>
	Deverá indicar um ISBN correto (13 caracteres)<br>
	<?php endif; ?>
	Observações:<textarea name="observacoes"></textarea><br>
	Imagem capa:<input type="text" name="imagem_capa"><br>
	Género:<input type="text" name="id_genero"><br>
	Autor:<input type="text" name="Autor"><br>
	Sinopse:<textarea name="sinopse"><?php echo e(old('sinopse')); ?></textarea><br>
	<input type="submit" value="enviar">
	
	
</form><?php /**PATH D:\Atv6\livraria\resources\views/livros/create.blade.php ENDPATH**/ ?>