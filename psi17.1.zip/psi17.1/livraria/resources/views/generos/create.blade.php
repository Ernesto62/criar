<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="{{route('generos.store')}}" method="post">
@csrf
Designação: <input type="text" name="designacao"><br>
@if($errors->has('designacao'))
Deverá indicar uma Designação correta<br>
@endif
Observações: <input type="text" name="observacoes"><br>
<input type="submit" value="Enviar!">
@if($errors->has('observacoes'))
Deverá indicar uma observação correta <br>
@endif
</form>






</body>
</html>