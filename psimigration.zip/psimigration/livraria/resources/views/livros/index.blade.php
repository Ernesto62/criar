<ul>
@foreach($livros as $livro)
<li>
	<a href="{{route('livros.show', ['id'=>$livro->id_livro])}}">
	
	{{$livro->titulo}}</a>

	
@endforeach
</ul>

<a href="{{route('livros.create', ['id'=>$livro->id_livro])}}">Criar</a>