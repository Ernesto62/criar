<h2>Deseja eliminar o genero: </h2>
<h2><?php echo e($genero->designacao); ?></h2>
<form method="post" action="<?php echo e(route('generos.destroy',['id'=>$genero->id_genero])); ?>">
	<?php echo csrf_field(); ?>
	<?php echo method_field('delete'); ?>
	<input type="submit" name="enviar">
</form>

<?php if(session()->has('mensagem')): ?>
<div class="alert alert-danger" role="alert"><?php echo e(session('mensagem')); ?>

	<?php echo e(session('mensagem')); ?>

	<?php endif; ?>



<?php /**PATH D:\psi17.1\livraria\resources\views/generos/delete.blade.php ENDPATH**/ ?>